export const emotions = {
  Fear: "😨",
  Angry: "😠",
  Sad: "😞",
  Surprise: "😲",
  Happy: "😄",
};
