const NEW_USER_REGISTRATION_CODED_STRING = "new_user_registration_detected";

export { NEW_USER_REGISTRATION_CODED_STRING };
