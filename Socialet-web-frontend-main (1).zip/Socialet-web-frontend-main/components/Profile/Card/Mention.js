import React from "react";

function Mention() {
  return <div>Mention</div>;
}

export default Mention;
